-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2020 at 03:07 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `storytelling`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$tf0y0XX8LgfDh0JaTu4Zv.Lym//fqYoaXiPyzMWcfdoY/wkEdy1gC');

-- --------------------------------------------------------

--
-- Table structure for table `design`
--

CREATE TABLE `design` (
  `id` int(11) NOT NULL,
  `keterangan` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `page_order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `filestory`
--

CREATE TABLE `filestory` (
  `id` int(11) NOT NULL,
  `user` int(50) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `group_diss`
--

CREATE TABLE `group_diss` (
  `id` int(11) NOT NULL,
  `group_name` varchar(50) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `user2` int(50) NOT NULL,
  `user3` int(50) NOT NULL,
  `user4` int(50) NOT NULL,
  `user5` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `info_admin`
--

CREATE TABLE `info_admin` (
  `id` int(11) NOT NULL,
  `informasi` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info_admin`
--

INSERT INTO `info_admin` (`id`, `informasi`) VALUES
(6, 'Please read the instructions carefully before you start.');

-- --------------------------------------------------------

--
-- Table structure for table `outline_desc`
--

CREATE TABLE `outline_desc` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `pilih` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `peer_reflection`
--

CREATE TABLE `peer_reflection` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `username` varchar(200) NOT NULL,
  `pilih` int(11) NOT NULL,
  `pilih_user` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `peer_reflection2`
--

CREATE TABLE `peer_reflection2` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `username` varchar(200) NOT NULL,
  `pilih` int(11) NOT NULL,
  `pilih_user` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `peer_reflection3`
--

CREATE TABLE `peer_reflection3` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `username` varchar(200) NOT NULL,
  `pilih` int(11) NOT NULL,
  `pilih_user` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `presentation`
--

CREATE TABLE `presentation` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `pilih` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purpose_desc`
--

CREATE TABLE `purpose_desc` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `pilih` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reflect`
--

CREATE TABLE `reflect` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `pilih` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reflect2`
--

CREATE TABLE `reflect2` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `pilih` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_comments`
--

CREATE TABLE `teacher_comments` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `username` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_comments`
--

INSERT INTO `teacher_comments` (`id`, `nama`, `user`, `username`) VALUES
(2, 'Keren', 1, 'admin'),
(3, 'Bahus sekali', 1, 'admin'),
(4, 'Keren sekali', 1, 'admin'),
(5, 'Mantap', 1, 'admin'),
(6, 'Keren mantap', 1, 'admin'),
(7, 'Alhamdulillah', 1, 'admin'),
(8, 'Mantap', 1, '			miqbalhanafri		'),
(9, 'Keren', 1, '			miqbalhanafri		'),
(10, 'Bagus sekali', 1, '			miqbalhanafri		'),
(11, 'Keren', 1, '			miqbalhanafri		'),
(12, 'Mantap', 1, '			mona		');

-- --------------------------------------------------------

--
-- Table structure for table `theme`
--

CREATE TABLE `theme` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `pilih` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='tabel tema storytelling';

-- --------------------------------------------------------

--
-- Table structure for table `theme_reason`
--

CREATE TABLE `theme_reason` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `pilih` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `theme_reason2`
--

CREATE TABLE `theme_reason2` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `pilih` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tools_desc`
--

CREATE TABLE `tools_desc` (
  `id` int(11) NOT NULL,
  `nama` varchar(10000) NOT NULL,
  `user` int(50) NOT NULL,
  `pilih` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `design`
--
ALTER TABLE `design`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filestory`
--
ALTER TABLE `filestory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `group_diss`
--
ALTER TABLE `group_diss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info_admin`
--
ALTER TABLE `info_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `outline_desc`
--
ALTER TABLE `outline_desc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `peer_reflection`
--
ALTER TABLE `peer_reflection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `peer_reflection2`
--
ALTER TABLE `peer_reflection2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `peer_reflection3`
--
ALTER TABLE `peer_reflection3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `presentation`
--
ALTER TABLE `presentation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purpose_desc`
--
ALTER TABLE `purpose_desc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reflect`
--
ALTER TABLE `reflect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reflect2`
--
ALTER TABLE `reflect2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_comments`
--
ALTER TABLE `teacher_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `theme`
--
ALTER TABLE `theme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `theme_reason`
--
ALTER TABLE `theme_reason`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `theme_reason2`
--
ALTER TABLE `theme_reason2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tools_desc`
--
ALTER TABLE `tools_desc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `design`
--
ALTER TABLE `design`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `filestory`
--
ALTER TABLE `filestory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `group_diss`
--
ALTER TABLE `group_diss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `info_admin`
--
ALTER TABLE `info_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `outline_desc`
--
ALTER TABLE `outline_desc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `peer_reflection`
--
ALTER TABLE `peer_reflection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `peer_reflection2`
--
ALTER TABLE `peer_reflection2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `peer_reflection3`
--
ALTER TABLE `peer_reflection3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `presentation`
--
ALTER TABLE `presentation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `purpose_desc`
--
ALTER TABLE `purpose_desc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `reflect`
--
ALTER TABLE `reflect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reflect2`
--
ALTER TABLE `reflect2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `teacher_comments`
--
ALTER TABLE `teacher_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `theme`
--
ALTER TABLE `theme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `theme_reason`
--
ALTER TABLE `theme_reason`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `theme_reason2`
--
ALTER TABLE `theme_reason2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tools_desc`
--
ALTER TABLE `tools_desc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
